//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {

    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 200, width: 200, height: 20)
        label.text = "4111-1111-1111-2121"
        if ((label.text?.luhnCheck()) != nil) {
            print("CCCCCCC")
            label.text = "NOT CCCCCCCCCCCC "
        }
        label.textColor = .black
        
        view.addSubview(label)
        self.view = view
        let string = "Want to go Chicago and pay my hotel with 4111-1111-1111-1111 and pay my airfare with 3566000020000410 not sure we don't need to mask 374245455400126"
        print(string.maskedMessage())
    }



}
extension String {
    static let creditCardRegex = "(((((((?:[1-9][\\s-]*)(?:\\d[\\s-]*){11}\\d)[\\s-]*\\d?)[\\s-]*\\d?)[\\s-]*\\d?)[\\s-]*\\d?)[\\s-]*\\d?)[\\s-]*\\d?"
    static let creditCardMaskedString = "xxxx-xxxx-xxxx-xxxx"

    //retuns the message masked with credit card number masked as xxxx-xxxx-xxxx-xxxx
    func maskedMessage() -> String {
        var maskedMesage = self
        let matchingCards = matches(for: String.creditCardRegex, in: self)

        for cardMatch in matchingCards {
            let trimmedCard = cardMatch.trimmingLeadingAndTrailingSpaces()
            if trimmedCard.luhnCheck() {
                maskedMesage = maskedMesage.replacingOccurrences(of: trimmedCard, with: String.creditCardMaskedString)
            }
        }
        return maskedMesage
    }

    //returns the matching array of strings with regex.
    private func matches(for regex: String, in text: String) -> [String] {
        do {
            let regex = try NSRegularExpression(pattern: regex)
            let results = regex.matches(in: text,
                                        range: NSRange(text.startIndex..., in: text))
            let finalResult = results.map {
                String(text[Range($0.range, in: text)!])
            }
            return finalResult
        } catch let error {
            print("invalid regex: \(error.localizedDescription)")
            return []
        }
    }

    func trimmingLeadingAndTrailingSpaces(using characterSet: CharacterSet = .whitespacesAndNewlines) -> String {
            return trimmingCharacters(in: characterSet)
        }

    //luhn algorithm to check if given number is credit card or not.
    func luhnCheck() -> Bool {
        let cleanedInput = self.replacingOccurrences(of: "[^0-9]", with: "", options: .regularExpression)
        var sum = 0
        let digitStrings = cleanedInput.reversed().map { String($0) }

        for tuple in digitStrings.enumerated() {
            if let digit = Int(tuple.element) {
                let odd = tuple.offset % 2 == 1

                switch (odd, digit) {
                case (true, 9):
                    sum += 9
                case (true, 0...8):
                    sum += (digit * 2) % 9
                default:
                    sum += digit
                }
            } else {
                return false
            }
        }
        return sum % 10 == 0
    }
}

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()

